import React, { useState } from "react";
import "./App.css";

function App() {
  const [products, setProducts] = useState([
    { id: 1, name: "티셔츠", price: 20000 },
    { id: 2, name: "청바지", price: 30000 },
    { id: 3, name: "운동화", price: 50000 },
  ]);

  const [cart, setCart] = useState([]);

  const addToCart = (product) => {
    setCart([...cart, product]);
  };

  return (
    <div className="App">
      <h1>쇼핑몰</h1>
      <div className="products">
        <h2>상품 목록</h2>
        <ul>
          {products.map((product) => (
            <li key={product.id}>
              {product.name} - {product.price}원{" "}
              <button onClick={() => addToCart(product)}>
                장바구니에 추가
              </button>
            </li>
          ))}
        </ul>
      </div>
      <div className="cart">
        <h2>장바구니</h2>
        <ul>
          {cart.map((item, index) => (
            <li key={index}>
              {item.name} - {item.price}원
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default App;
